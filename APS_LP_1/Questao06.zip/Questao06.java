package auladelogica;

import java.util.Scanner;

import javax.swing.JOptionPane;

import java.lang.Math;

//Fa�a um Programa para uma loja de tintas. O programa dever� pedir o tamanho em
//metros quadrados da �rea a ser pintada. Considere que a cobertura da tinta � de 1 litro
//para cada 6 metros quadrados e que a tinta � vendida em latas de 18 litros, que custam
//R$ 80,00 ou em gal�es de 3,6 litros, que custam R$ 25,00.
//Informe ao usu�rio as quantidades de tinta a serem compradas e os respectivos pre�os
//em 3 situa��es:
//a. comprar apenas latas de 18 litros;
//b. comprar apenas gal�es de 3,6 litros;
//c. misturar latas e gal�es, de forma que o desperd�cio de tinta seja menor. Acrescente
//10% de folga e sempre arredonde os valores para cima, isto �, considere latascheias.

public class Questao06 {

	public static void main(String[] args) {
		 
		Scanner scan= new Scanner(System.in);
		JOptionPane.showMessageDialog(null,"N�o consegui fazer o item C ");	
		
		double lit1=18,lit2=3.6;
		double p1=80.0,p2=25.0;
		double metros=0;
		double litros=0;
		double m2=6;
		double latas=0;
		double resto=0;
		
		System.out.println("Digite a �rea em m2 a ser pintada:");
		metros=scan.nextDouble();
		litros=metros/m2;
		latas=litros/lit1;
		System.out.println("Por latas de 18L voc� vai precisar de:" +Math.round(latas)+" lata(as) e pagara o valor em reais de:"+Math.round(latas)*p1 );//item "A"
		latas=litros/lit2;
		System.out.println("Por gal�es de 3,6L voc� vai precisar de:" +Math.round(latas)+" gal�o(�es) e pagara o valor em reais de:"+Math.round(latas)*p2);// item "B"
	}
}
