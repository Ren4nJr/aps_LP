package questoes;
/* Chico tem 1,50m e cresce 2 cent�metros por ano, enquanto Juca tem 1,10m e cresce 3 
cent�metros por ano. Construir um algoritmo que calcule e imprima quantos anos ser�o 
necess�rios para que Juca seja maior que Chico.*/

import java.util.Scanner;

public class Questao05 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int tamChico = 150, tamJuca = 110, anos = 0; //tamanho em cm
		 while(tamJuca <= tamChico) {
			 
			 tamChico += 2;
			 tamJuca +=3;
			 anos++;
		 }
		 
		 System.out.printf("Ser�o necess�rio "+anos+" anos para que Juca seja maior que Chico.");
	}

}
