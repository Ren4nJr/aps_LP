package questoes;

import java.util.Scanner;

/* Crie um algoritmo que ajude o DETRAN a saber, o total de recursos que foram arrecadados 
com a aplica��o de multas de tr�nsito. O algoritmo deve ler as seguintes informa��es para 
cada motorista: 
-O n�mero da carteira de motorista (de 1 a 4327) 
-N�mero de multas; 
-Valor da cada uma das multas. 
Deve ser impresso o valor da d�vida de cada motorista e ao final da leitura o total de recursos 
arrecadados (somat�rio de todas as multas). O algoritmo dever� imprimir tamb�m o n�mero 
da carteira do motorista que obteve o maior n�mero de multas.*/
public class Questao01 {

	public static void main(String[] args) {
		int numDcrt,numMlt,valordml,valorf,valorf2,motMAIOR;
		Scanner in = new Scanner(System.in);
		
		System.out.println("N�O CONSEGUIR ENTENDER:");
		

	}

}
