package questoes;

import java.util.Scanner;

public class Questao04 {

   public static void main(String[] args) {

       Scanner in = new Scanner(System.in);
       int numeroRecebido = 0;
       int quantidadeNumeros = 0;

       System.out.println("Digite um numero:");
       numeroRecebido = in.nextInt();

       while(numeroRecebido != 0){

           if(numeroRecebido > 100 && numeroRecebido < 200){

               quantidadeNumeros++;

           }
           
           System.out.println("Foram digitados " + quantidadeNumeros + " n�meros entre 100 e 200.");
       }

       

   }

}