package auladelogica;

import java.util.Scanner;

import javax.xml.namespace.QName;

//Fa�a um algoritmo para ler: a descri��o do produto (nome), a quantidade 
//adquirida e o pre�o unit�rio. Calcular e escrever o total (total = quantidade 
//adquirida * pre�o unit�rio), o desconto e o total a pagar (total a pagar = total -
//desconto), sabendo-se que 
//se quantidade <= 5 o desconto sera de 2%
//se quantidade > 5 e quantidade <= 10 o desconto sera de 3%
//se quantidade > 10 desconto sera de 5%

public class Questao_aps2_06 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		String produto = "";
		int qntAdq;
		double precoUni = 0, valorTotal, valorFinal;
		
		System.out.println("Qual o produto?");
		produto = in.next();
		
		System.out.println("Qual o pre�o da unidade?");
		precoUni = in.nextDouble();
		
		System.out.println("Quantidade adquirida: ");
		qntAdq = in.nextInt();
		
		valorTotal = qntAdq * precoUni;
		
		if(qntAdq <= 5) {
			
			valorFinal = valorTotal - valorTotal * 0.02;
			
		}else if(qntAdq > 5 && qntAdq <=10) {
			
			valorFinal = valorTotal - valorTotal * 0.03;
			
		}else {
			
			valorFinal = valorTotal - valorTotal * 0.05;
			
		}
		
		System.out.print("Produto comprado: "+produto+"\n");
		System.out.print("Unidades compradas: "+qntAdq);
		System.out.printf("\n" + "O valor total da compra �: %.2f ", valorTotal, "\n");
		System.out.printf("\n" + "O valor final da compra com desconto �: %.2f ", valorFinal);
		
		}
	}
