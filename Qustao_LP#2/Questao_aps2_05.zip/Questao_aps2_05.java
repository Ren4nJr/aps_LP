package auladelogica;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//Fa�a um programa de convers�o de base num�rica. O programa dever� 
//apresentar uma tela de entrada com as seguintes op��es:
//< Convers�o de base >
//1: decimal para hexadecimal
//2: hexadecimal para decimal
//3: decimal para octal
//4: octal para decimal
//Lembre que, voc� deve informar as op��es para que a partir da op��o escolhida, o 
//programa deva pedir o n�mero na base escolhida, l�-lo e apresent�-lo na base 
//desejada.

public class Questao_aps2_05 {

	public static void main(String[] args) {
		public String decimalToHexadecimal(int number) {
		
	        List<String> vet = new ArrayList<String>();
	        StringBuilder result = new StringBuilder();
		
	
	        do {
	            if (number % 16 < 10) {
	                String aux = "" + number % 16;
	                vet.add(aux);
	            } else {
	                switch (number % 16) {
	                    case 10 :
	                        vet.add("A");
	                        break;
	                    case 11:
	                        vet.add("B");
	                        break;
	                    case 12:
	                        vet.add("C");
	                        break;
	                    case 13:
	                        vet.add("D");
	                        break;
	                    case 14:
	                        vet.add("E");
	                        break;
	                    case 15:
	                        vet.add("F");
	                }
	            }
	            number = (int) number / 16;
	        } while (number != 0);

	        for (int i = vet.size() - 1; i >= 0; i--)
	            result.append(vet.get(i));

	        return String.format("%s", result);
	    

	}

}

