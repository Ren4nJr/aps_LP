package auladelogica;

import java.util.Scanner;

public class Questao03 {

	public static void main(String[] args) {
		 
		Scanner scan= new Scanner(System.in);
		
		int n1,n2,prod;
		double n3,cubo,soma;
		System.out.println("Digite dois n�meros inteiros e um n�mero real:");
		
		n1= scan.nextInt();
		n2= scan.nextInt();
		n3= scan.nextDouble();
		
		prod = (2*n1)*(n2/2);
		soma =(3*n1)+n3;
		cubo = (n3*n3*n3);
		
		System.out.println(" O produto do dobro do primeiro com a metade do segundo �:" + prod);
		System.out.println(" A soma do triplo do primeiro com o terceiro �:"+soma);
		System.out.println(" O terceiro elevado ao cubo �:"+cubo);
		

		
		
		
		
	}

}
